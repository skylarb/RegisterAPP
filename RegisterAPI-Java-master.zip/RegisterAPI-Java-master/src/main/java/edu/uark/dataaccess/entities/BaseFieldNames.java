package edu.uark.dataaccess.entities;

public class BaseFieldNames {
	public static final String ID = "id";
	public static final String CREATED_ON = "createdon";
}
