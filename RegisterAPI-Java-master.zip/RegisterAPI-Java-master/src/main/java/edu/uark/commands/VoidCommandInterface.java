package edu.uark.commands;

public interface VoidCommandInterface {
	void execute();
}
