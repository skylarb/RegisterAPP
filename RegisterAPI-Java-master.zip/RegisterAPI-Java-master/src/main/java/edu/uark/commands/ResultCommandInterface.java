package edu.uark.commands;

public interface ResultCommandInterface<T> {
	T execute();
}
