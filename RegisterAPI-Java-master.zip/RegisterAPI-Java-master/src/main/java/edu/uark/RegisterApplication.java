package edu.uark;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegisterApplication {

	public static void main(String[] args) {
		//to be uncommented
	SpringApplication.run(RegisterApplication.class, args);
		
		//System.out.println("Hey my very first spring boot server");
	}
}
